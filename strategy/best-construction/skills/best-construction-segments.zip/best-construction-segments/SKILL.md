---
name: "best-construction-segments"
description: "Best Construction's three lead engines, segment-to-service mapping and outreach positioning. Use for ANY lead generation, outreach drafting, briefing, bid, or marketing work for Best Construction (bestconstruction.pro): commercial/public, residential homeowners, and property management/HOA/multifamily."
---

# Best Construction — Lead Engines and Segment-to-Service Mapping

Best Construction Inc. (Pinole, CA — bestconstruction.pro, info@bestconstruction.pro). California general contractor, 19+ years in the Bay Area, licensed & insured, BBB-accredited. Service area: ~100-mile radius around Pinole (SF Bay Area + surrounding counties).

Always pitch the RIGHT services to the RIGHT segment. Never mix segments' offerings, and never mix lead engines: each engine has its own targeting, scoring and outreach style.

This mapping mirrors `segments` and `lead_engines` in `strategy/best-construction/company-profile.yaml` (agency-agents fork). If the two ever differ, flag it to Rafa instead of guessing; licences, insurance, bonding and certifications come only from that profile.

## Engine 1 — Commercial / Public

| Segment | Services to pitch | Pitch angle |
|---|---|---|
| **Home builders / new-home buyers** | Outdoor Living Partner Program ONLY: fixed-price backyard packages sold as design-studio options. 3 tiers: Backyard Foundation $12K (builder margin $3.5K), Outdoor Living $32K ($10K), Ultimate Oasis $62K ($20K). | Margin per home + finished-yard models sell homes. Zero-risk 90-day pilot: one model backyard at cost, measure attach rate. ~$320K margin per 100 homes at 40% attach. |
| **General contractors (sub work)** | Driveways, patio pavers, demolition, excavation. | One sub for demo/excavation + paver install, line-item bids, CalGreen haul-off included, photo-documented, open capacity, get on bid list. |
| **Developers (active projects)** | Demolition + hardscape (patios, courtyards, pavers) under one contract. | Tie to their specific project signal (permits, teardowns, approvals). Ask to get on the bid list before packages go out. |
| **Commercial property (offices, retail, industrial)** | Asphalt/parking-lot paving, concrete, sidewalks & walkways, ADA exterior improvements, demolition, excavation. | Line-item pricing, phased work that keeps the business open, photo-documented for records. |
| **Public agencies** (cities, counties, school districts, state, federal) | Demolition, excavation, grading, concrete, sidewalks & walkways, ADA exterior improvements, paving, pavers, build & remodel. | Responsive, compliant bids. Contact only through the channel the solicitation names, only while allowed. Never claim a certification, registration or bonding capacity not in the company profile. |
| **Utilities & infrastructure** (water/sewer districts, transit, ports, energy) | Excavation, grading, concrete, demolition. | Reliable site-work sub or prime; safety record; capacity. |
| **Prime contractors seeking subs** (public jobs with SBE/DBE goals) | Whichever of our scopes the prime needs, from the lists above. | Scope, capacity, and only the certifications we actually hold. |

Scoring: go/no-go plus win probability. First touch: signal-based business email.

## Engine 2 — Residential (homeowners with real intent)

| Segment | Services to pitch | Pitch angle |
|---|---|---|
| **Homeowners** | Concrete, driveways, pavers, patios & hardscape, retaining walls, excavation, grading, demolition, land clearing, drainage, ADU site preparation, home remodeling, outdoor living projects. | Tie to their specific signal (ADU/grading/driveway permit, planning application, new purchase, inbound request). One clear offer: free site walk + fixed-price line-item quote. Plain, neighbourly, never pushy. |

- Work from intent signals (permits, applications, inbound, platform and referral leads), not mailing lists.
- Score 0–100: 80+ HOT, 60–79 WARM, 40–59 NURTURE, under 40 LOW PRIORITY.
- Permit-only leads: first touch is a mailed letter or door hanger. No cold calls or texts without a do-not-call process and consent. Email only to people who gave it to us.
- Never collect or infer sensitive personal information; use a homeowner's name only when it is lawfully public.
- The builder Outdoor Living Partner Program tiers are for builders only. Homeowners get custom outdoor-living quotes.

## Engine 3 — Property Management / HOA / Multifamily

| Segment | Services to pitch | Pitch angle |
|---|---|---|
| **Apartment communities, condos, HOAs, property-management and community-association-management companies, multifamily owners** | Concrete repair & replacement, sidewalks & walkways, trip-hazard repairs, ADA exterior improvements, asphalt/paving where applicable, pavers (incl. pool deck), retaining walls, drainage, grading, excavation, demolition, land clearing, hardscape, common-area and courtyard renovation, pool-area hardscape, fences & exterior improvements, building exterior renovation, unit and common-area remodeling, site work, emergency construction repairs. | Long-term vendor partner, not a one-job contractor. Line-item bids easy for boards, photo-documented for records, works around tenant and resident schedules, emergency response, walk the property → fixed number. |

- Treat management companies as accounts: Company → Regional managers → Properties → Opportunities → Contacts. Win the vendor relationship, then expand across the portfolio.
- Find the real construction decision-maker (regional PM, facilities/maintenance director, capital projects, asset manager, community manager), not a generic inbox.
- Score 0–100 with the same bands as Residential.
- Vendor-registration packets are drafts until Rafa approves submission.

## Voice
Practical contractor voice, no jargon. Concrete: square footage, fixed prices, timelines, what's included. Sign as "Rafa, Best Construction — bestconstruction.pro".

## Standing assets
- Pitch deck: "Outdoor_Living_Partner_Program.pptx" (8 slides, builder-facing). Attach to builder outreach only.
- Daily lead briefing emails go to info@bestconstruction.pro with subject "Daily Leads — [date]", with one section per engine.

## Outreach hygiene
- Send max 5-6 cold emails/day from the domain, across all engines combined.
- Verified emails only (Apollo enrichment).
- One primary contact per company first; spares held in reserve.
- Every email needs an opt-out line and the physical address.
- Nothing is sent without Rafa's explicit approval of that specific message.
